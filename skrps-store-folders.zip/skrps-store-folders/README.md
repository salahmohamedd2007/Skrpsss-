# Skrps Studio — موقع كامل (سيرفر + قاعدة بيانات + لوحة تحكم)

بدون أي مكتبات خارجية. محتاج **Node.js 22.13 أو أحدث** بس.

## أسرع طريقة
1. نزّل Node.js (النسخة LTS) من nodejs.org لو مش عندك.
2. فك الضغط واضغط دبل كليك على **`start.bat`** (ويندوز) أو شغّل `./start.sh` (ماك/لينكس).
3. الموقع هيفتح على http://localhost:3000 والأونر على http://localhost:3000/admin
4. غيّر كلمة السر من ملف **`.env`** (سطر `ADMIN_PASSWORD`) وأعد التشغيل.

## تشغيل بالأوامر
```bash
cd skrps-store
ADMIN_PASSWORD=كلمة_سر_قوية node server.js      # على Windows PowerShell:  $env:ADMIN_PASSWORD="..." ; node server.js
```
- الموقع: http://localhost:3000
- صفحة الأونر (الأدمن): http://localhost:3000/admin  (نفس `index-owner.html`) — كلمة السر = ADMIN_PASSWORD، الافتراضي 11111، غيّرها!

## الهيكل
| ملف | وظيفته |
|---|---|
| `public/index.html` | **موقع العملاء كله في ملف واحد** (HTML + CSS + JavaScript) |
| `public/index-owner.html` | **صفحة الأونر كلها في ملف واحد** (HTML + CSS + JavaScript) |
| `server.js` | السيرفر + الـ API + التحقق من بيانات العميل |
| `db.js` | طبقة قاعدة البيانات: SQLite محلي أو Turso (لـ Vercel) |
| `api/index.js` + `vercel.json` | نقطة دخول Vercel |
| `seed.json` | المنتجات والإعدادات الأولية |
| `data/shop.db` | قاعدة البيانات (بتظهر بعد أول تشغيل) — اعمل منها نسخة احتياطية |
| `public/img/` | الصور |
| `.env` | كلمة سر الأدمن والبورت |

## اللي بيحصل
- الطلب مش بيتقبل غير باسم + موبايل مصري صحيح + إيميل + عنوان كامل + طريقة دفع (بيتفحص في الصفحة وفي السيرفر).
- كل طلب بيتسجل في قاعدة البيانات ويظهر في `/admin` (تبويب Orders / Customers) خلال 10 ثواني، والمخزون بينقص أوتوماتيك، وبيرجع لو كنسلت الطلب.
- أي تعديل في الأدمن (منتجات، أسعار، مخزون، إعدادات، صورة رئيسية، نصوص) بيتحفظ في القاعدة فوراً وبيظهر للعملاء على طول، وتظهر شارة "✓ Saved to database".
- حماية: كلمة سر الأدمن، تحديد محاولات الدخول (10 كل 15 دقيقة) وعدد الطلبات (12 في الساعة للـ IP).

## النشر على Vercel (الموقع + الأدمن مع بعض)
1. ارفع المجلد على GitHub (ملف `.env` مش بيترفع، ده مقصود).
2. في Vercel: **Add New → Project** → اختار الريبو → Deploy. (Framework: Other، من غير Build Command.)
3. من **Settings → Environment Variables** ضيف **`ADMIN_PASSWORD`** (إجباري، من غيره الأدمن بيفضل مقفول) وبعدها **Redeploy**.
4. الموقع على `https://اسم-مشروعك.vercel.app` والأدمن على `/admin`.

**الحفظ الدائم (مهم):** من غير قاعدة بيانات خارجية الموقع بيشتغل في وضع تجريبي بيتخزن فيه مؤقتاً (الطلبات والتعديلات ممكن تختفي)، وبتظهر في الأدمن شارة صفرا بتقول كده. للحفظ الدائم:
1. اعمل حساب مجاني على turso.tech وأنشئ قاعدة بيانات.
2. انسخ **Database URL** (`libsql://...`) و **Auth Token**.
3. في Vercel ضيف المتغيرين: `TURSO_DATABASE_URL` و `TURSO_AUTH_TOKEN` → Redeploy.
الجداول والمنتجات بتتعمل لوحدها أول طلب.

## النشر على استضافة بتشغّل Node (بديل)
- **Render (الأسهل):** ارفع المجلد على GitHub، وفي Render اختار New → Blueprint، وهو هيقرأ `render.yaml` ويجهز القرص تلقائي؛ حط `ADMIN_PASSWORD` وخلاص.
- **Railway / Fly.io:** ارفع المجلد على GitHub، اعمل Web Service، Start command: `node server.js`، وضيف متغيرات `ADMIN_PASSWORD`، وركّب Disk/Volume على مجلد `data` عشان القاعدة متتمسحش.
- **VPS:** `ADMIN_PASSWORD=... PORT=3000 node server.js` (استخدم pm2 أو systemd) وNginx قدامه مع HTTPS.
- **Docker:** `docker build -t skrps . && docker run -p 3000:3000 -e ADMIN_PASSWORD=... -v skrps-data:/app/data skrps`

متغيرات البيئة: `PORT`، `ADMIN_PASSWORD`، `DB_FILE` (مسار ملف القاعدة، اختياري).
مهم: فعّل HTTPS دايماً في الإنتاج لأن كلمة سر الأدمن بتتبعت مع كل طلب إدارة.
