/* Skrps Studio — storefront: catalogue, cart, search */
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let products = [],
  cart = JSON.parse(localStorage.getItem("skrps-cart") || "[]"),
  adminKey = sessionStorage.getItem("skrps-admin") || "",
  adminData = null;
const money = (n) => `${Number(n).toLocaleString("en-EG")} EGP`;
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
let toastTimer;
function notice(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 2800);
}
function art(color) {
  return `<div class="scrub" style="--tone:${esc(color)}"><div class="jacket"><i></i><b></b></div><div class="trousers"></div></div><div class="plinth"></div>`;
}
/* WhatsApp chat button + contact links, driven by Settings in the owner page */
function renderContact(s) {
  const wa = String(s.whatsapp || "")
    .replace(/\D/g, "")
    .replace(/^0/, "20");
  const mail = String(s.contactEmail || "").trim();
  let btn = $("#waFloat");
  if (!btn) {
    btn = document.createElement("a");
    btn.id = "waFloat";
    btn.target = "_blank";
    btn.rel = "noopener";
    btn.innerHTML =
      '<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M4 4h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4v-4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/></svg><span>Chat with us</span>';
    document.body.appendChild(btn);
  }
  btn.hidden = !wa;
  btn.href =
    "https://wa.me/" + wa + "?text=" + encodeURIComponent("Hello Skrps, I have a question.");
  const box = $("#contactLinks");
  if (box)
    box.innerHTML =
      (wa ? `<a href="https://wa.me/${wa}" target="_blank" rel="noopener">WHATSAPP ↗</a>` : "") +
      (mail ? `<a href="mailto:${esc(mail)}">EMAIL ↗</a>` : "");
}
async function loadStore() {
  try {
    const r = await fetch("/api/products");
    const d = await r.json();
    if (!r.ok) throw Error(d.error);
    products = d.products;
    $("#announcementText").textContent =
      d.settings?.announcement || "Free delivery on orders over 3,000 EGP";
    renderContact(d.settings || {});
    renderProducts();
    renderCart();
  } catch (e) {
    $("#productGrid").innerHTML =
      `<div class="loading">${esc(e.message)} — please refresh to try again.</div>`;
  }
}
function renderProducts() {
  const filter = $("#colourFilter").value;
  $("#productGrid").innerHTML =
    products
      .filter((p) => filter === "all" || p.color === filter)
      .map(
        (p) =>
          `<article class="product-card"><div class="product-visual" data-product="${esc(p.id)}"><span class="product-badge">${esc(p.badge || p.category.toUpperCase())}</span><img class="product-photo" src="${IMG(p.photo)}" alt="${esc(p.color)} scrub set, top and trousers" loading="lazy"><button class="quick-add" data-add="${esc(p.id)}" aria-label="Add ${esc(p.name)} to bag">+</button></div><div class="product-info"><span class="product-name">${esc(p.name)}</span><b class="product-price">${money(p.price)}</b><span class="product-meta">${esc(p.color)} &nbsp;·&nbsp; ${esc(p.category)} &nbsp;·&nbsp; Unisex</span><div class="product-colour"><i class="colour-dot" style="background:${esc(p.hex)}" title="${esc(p.color)}"></i><span style="font-size:8px;color:#8b8c82">Made for everyone</span></div></div></article>`,
      )
      .join("") || '<div class="loading">No colours found.</div>';
  $$("[data-add]").forEach((b) => (b.onclick = () => addToCart(b.dataset.add)));
}
$("#colourFilter").addEventListener("change", renderProducts);
function persistCart() {
  localStorage.setItem("skrps-cart", JSON.stringify(cart));
  renderCart();
}
function addToCart(id) {
  const p = products.find((x) => x.id === id);
  if (!p) return;
  const found = cart.find((x) => x.id === id && x.size === "M");
  if (found) found.quantity++;
  else cart.push({ id, size: "M", quantity: 1 });
  persistCart();
  notice(`${p.name} added to your bag.`);
}
function cartDetails() {
  return cart
    .map((line) => ({ line, p: products.find((x) => x.id === line.id) }))
    .filter((x) => x.p);
}
function renderCart() {
  const lines = cartDetails(),
    count = lines.reduce((a, x) => a + x.line.quantity, 0),
    total = lines.reduce((a, x) => a + x.line.quantity * x.p.price, 0);
  $("#cartCount").textContent = count;
  $("#bagHeadingCount").textContent = `(${count})`;
  $("#cartSubtotal").textContent = money(total);
  $("#checkoutTotal").textContent = money(total);
  $("#cartEmpty").style.display = lines.length ? "none" : "block";
  $("#cartFoot").style.display = lines.length ? "block" : "none";
  $("#cartItems").innerHTML = lines
    .map(
      ({ line, p }) =>
        `<div class="cart-line"><div class="cart-thumb"><img class="product-photo" src="${IMG(p.photo)}" alt="${esc(p.color)} scrub set" loading="lazy"></div><div><div class="cart-line-title">${esc(p.name)}</div><div class="cart-line-meta">${esc(p.color)} &nbsp;·&nbsp; Size ${esc(line.size)}</div><div class="qty-control"><button data-qty="${esc(p.id)}" data-delta="-1" aria-label="Reduce quantity">−</button>${line.quantity}<button data-qty="${esc(p.id)}" data-delta="1" aria-label="Increase quantity">+</button><button class="remove-item" data-remove="${esc(p.id)}">REMOVE</button></div></div><span class="cart-line-price">${money(line.quantity * p.price)}</span></div>`,
    )
    .join("");
  $$("[data-qty]").forEach(
    (b) =>
      (b.onclick = () => {
        const x = cart.find((i) => i.id === b.dataset.qty);
        x.quantity += Number(b.dataset.delta);
        if (x.quantity < 1) cart = cart.filter((i) => i !== x);
        persistCart();
      }),
  );
  $$("[data-remove]").forEach(
    (b) =>
      (b.onclick = () => {
        cart = cart.filter((i) => i.id !== b.dataset.remove);
        persistCart();
      }),
  );
}
function toggleLayer(layer) {
  const open = layer.classList.contains("open");
  closeLayers();
  if (!open) {
    layer.classList.add("open");
    $("#overlay").classList.add("active");
    document.body.style.overflow = "hidden";
  }
}
function closeLayers() {
  $$(".cart-drawer,.modal,.admin-panel").forEach((x) => x.classList.remove("open"));
  $("#overlay").classList.remove("active");
  document.body.style.overflow = "";
}
$("#cartOpen").onclick = () => toggleLayer($("#cartDrawer"));
$("#adminOpen").onclick = () => openAdmin();
$("#footerAdmin").onclick = () => openAdmin();
$("#overlay").onclick = closeLayers;
$$("[data-close]").forEach((b) => (b.onclick = closeLayers));
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeLayers();
});
$("#keepShopping").onclick = () => {
  closeLayers();
  $("#shop").scrollIntoView({ behavior: "smooth" });
};
$("#checkoutOpen").onclick = () => toggleLayer($("#checkoutModal"));
const methodHints = {
  cash: "Pay securely on delivery. We’ll be in touch to confirm.",
  card: "Card orders are recorded as awaiting payment. Secure card processing requires a connected payment provider.",
  wallet:
    "Wallet orders are recorded as awaiting payment. Your store will confirm the wallet transfer details.",
  instapay:
    "InstaPay orders are recorded as awaiting payment. Transfer details are shown right after ordering.",
  applepay:
    "Apple Pay orders are recorded as awaiting payment. You’ll get a secure Apple Pay link right after ordering.",
};
$$('[name="payment"]').forEach(
  (r) => (r.onchange = () => ($("#paymentHint").textContent = methodHints[r.value])),
);
$("#checkoutForm").onsubmit = async (e) => {
  e.preventDefault();
  const f = new FormData(e.target),
    btn = e.submitter;
  btn.disabled = true;
  btn.textContent = "Placing your order…";
  try {
    const r = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer: {
          name: f.get("name"),
          phone: f.get("phone"),
          email: f.get("email"),
          address: f.get("address"),
        },
        paymentMethod: f.get("payment"),
        items: cart.map((x) => ({ ...x })),
      }),
    });
    const d = await r.json();
    if (!r.ok) throw Error(d.error);
    cart = [];
    persistCart();
    e.target.reset();
    closeLayers();
    toggleLayer($("#cartDrawer"));
    notice(`Order ${d.order.id} is confirmed. Thank you!`);
  } catch (err) {
    notice(err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = "Place your order &nbsp; ↗";
  }
};
$("#newsletterForm").onsubmit = (e) => {
  e.preventDefault();
  e.target.innerHTML = "<p>✳ &nbsp; You’re on the list. Look out for a good thing.</p>";
};
function openAdmin() {
  closeLayers();
  $("#adminPanel").classList.add("open");
  document.body.style.overflow = "hidden";
  if (adminKey) loadDashboard();
}
$("#adminLoginForm").onsubmit = async (e) => {
  e.preventDefault();
  adminKey = new FormData(e.target).get("key");
  try {
    await fetchAdmin();
    sessionStorage.setItem("skrps-admin", adminKey);
    await loadDashboard();
  } catch (err) {
    notice(err.message);
  }
};
async function fetchAdmin(path = "/api/admin/overview", options = {}) {
  const r = await fetch(path, {
    ...options,
    headers: {
      Authorization: `Bearer ${adminKey}`,
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });
  const d = await r.json();
  if (!r.ok) {
    if (r.status === 401) {
      adminKey = "";
      sessionStorage.removeItem("skrps-admin");
    }
    throw Error(d.error || "Admin request failed.");
  }
  return d;
}
async function loadDashboard() {
  try {
    adminData = await fetchAdmin();
    $("#adminLogin").hidden = true;
    $("#dashboard").hidden = false;
    renderDashboard();
  } catch (e) {
    $("#adminLogin").hidden = false;
    $("#dashboard").hidden = true;
    if (adminKey) notice("Your admin key was not accepted. Please sign in again.");
  }
}
function renderDashboard() {
  const d = adminData,
    orders = d.orders || [],
    gross = orders.reduce((n, o) => n + o.total, 0),
    open = orders.filter((o) => !["Delivered", "Cancelled"].includes(o.status)).length,
    low = d.products.filter((p) => p.stock < 8).length;
  $("#dashboard").innerHTML =
    `<div class="dash-header"><div><p class="eyebrow">SKRPS STUDIO &nbsp; / &nbsp; STORE MANAGEMENT</p><h2>Your store, <em>at a glance.</em></h2><p>Products, incoming orders, pricing and the little details.</p></div><div class="dash-actions"><button class="small-button" id="dashRefresh">↻ &nbsp; REFRESH</button><button class="small-button dark" id="dashLogout">SIGN OUT &nbsp; ↗</button></div></div><div class="metric-grid"><div class="metric"><span>TOTAL REVENUE · ALL ORDERS</span><b>${money(gross)}</b></div><div class="metric"><span>ORDERS TO FULFIL</span><b>${open}</b></div><div class="metric"><span>ACTIVE PRODUCTS</span><b>${d.products.filter((p) => p.active !== false).length}</b></div><div class="metric"><span>LOW STOCK · UNDER 8</span><b>${low}</b></div></div><div class="dash-grid"><div class="dash-card"><h3>Recent orders &nbsp;·&nbsp; ${orders.length} total</h3><div class="table-wrap"><table class="dash-table"><thead><tr><th>ORDER</th><th>DATE</th><th>CUSTOMER</th><th>TOTAL</th><th>PAYMENT</th><th>STATUS</th></tr></thead><tbody>${
      orders.length
        ? orders
            .slice(0, 30)
            .map(
              (o) =>
                `<tr><td>${esc(o.id)}</td><td>${new Date(o.createdAt).toLocaleDateString()}</td><td>${esc(o.customer.name)}</td><td>${money(o.total)}</td><td>${esc(o.paymentMethod.toUpperCase())}</td><td><select class="status-select" data-status="${esc(o.id)}">${["New", "Processing", "Shipped", "Delivered", "Cancelled"].map((s) => `<option ${s === o.status ? "selected" : ""}>${s}</option>`).join("")}</select></td></tr>`,
            )
            .join("")
        : '<tr><td colspan="6">Your first order is just around the corner.</td></tr>'
    }</tbody></table></div></div><div class="dash-card"><h3>Products &amp; stock</h3><div class="stock-list">${d.products.map((p) => `<div class="stock-row"><div>${esc(p.name)}<br><small>${esc(p.color)} · ${money(p.price)}</small></div><label>QTY <input data-stock="${esc(p.id)}" type="number" min="0" value="${p.stock}"></label><button data-active="${esc(p.id)}">${p.active === false ? "RESTORE" : "HIDE"}</button></div>`).join("")}</div></div><div class="dash-card"><h3>Store announcement</h3><form class="settings-form" id="announcementForm"><label>ANNOUNCEMENT<input name="announcement" value="${esc(d.settings.announcement)}" maxlength="180"></label><button class="small-button dark">SAVE</button></form></div><div class="dash-card"><h3>One simple price for every set</h3><form class="settings-form" id="priceForm"><label>PRICE PER SET · EGP<input name="flatPrice" type="number" min="1" value="${d.settings.flatPrice}"></label><button class="small-button dark">UPDATE ALL</button></form><p style="font-size:8px;color:#808278">Changing this updates every product on the storefront.</p></div></div>`;
  $("#dashRefresh").onclick = loadDashboard;
  $("#dashLogout").onclick = () => {
    adminKey = "";
    sessionStorage.removeItem("skrps-admin");
    $("#adminLogin").hidden = false;
    $("#dashboard").hidden = true;
  };
  $$("[data-status]").forEach(
    (s) =>
      (s.onchange = async () => {
        try {
          await fetchAdmin(`/api/admin/orders/${encodeURIComponent(s.dataset.status)}`, {
            method: "PATCH",
            body: JSON.stringify({ status: s.value }),
          });
          await loadDashboard();
          notice("Order status updated.");
        } catch (e) {
          notice(e.message);
        }
      }),
  );
  $$("[data-active]").forEach(
    (b) =>
      (b.onclick = async () => {
        const p = d.products.find((x) => x.id === b.dataset.active);
        try {
          await fetchAdmin(`/api/admin/products/${encodeURIComponent(p.id)}`, {
            method: "PATCH",
            body: JSON.stringify({ active: p.active === false }),
          });
          await loadDashboard();
          await loadStore();
          notice(p.active === false ? "Product restored." : "Product hidden from the shop.");
        } catch (e) {
          notice(e.message);
        }
      }),
  );
  $$("[data-stock]").forEach(
    (i) =>
      (i.onchange = async () => {
        try {
          await fetchAdmin(`/api/admin/products/${encodeURIComponent(i.dataset.stock)}`, {
            method: "PATCH",
            body: JSON.stringify({ stock: i.value }),
          });
          await loadDashboard();
          notice("Stock level saved.");
        } catch (e) {
          notice(e.message);
        }
      }),
  );
  $("#announcementForm").onsubmit = async (e) => {
    e.preventDefault();
    try {
      await fetchAdmin("/api/admin/settings", {
        method: "PATCH",
        body: JSON.stringify({ announcement: new FormData(e.target).get("announcement") }),
      });
      await loadStore();
      await loadDashboard();
      notice("Announcement updated.");
    } catch (x) {
      notice(x.message);
    }
  };
  $("#priceForm").onsubmit = async (e) => {
    e.preventDefault();
    try {
      await fetchAdmin("/api/admin/settings", {
        method: "PATCH",
        body: JSON.stringify({ flatPrice: new FormData(e.target).get("flatPrice") }),
      });
      await loadStore();
      await loadDashboard();
      notice("All set prices have been updated.");
    } catch (x) {
      notice(x.message);
    }
  };
}
const io = new IntersectionObserver(
  (entries) =>
    entries.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add("visible");
        io.unobserve(e.target);
      }
    }),
  { threshold: 0.08 },
);
$$(".feature-grid article,.section-heading,.story-copy,.newsletter").forEach((e) => {
  e.classList.add("reveal");
  io.observe(e);
});
loadStore();
