/* Skrps Studio — checkout, quick view and admin dashboard */
/* Skrps Studio — UX layer: quick view, checkout flow, full admin dashboard */
let S = { deliveryFee: 80, freeOver: 3000 },
  tab = "overview",
  oq = "",
  of = "all";
const PHOTOS = [
  "midnight",
  "aegean",
  "olive",
  "berry",
  "cloud",
  "slate",
  "cobalt",
  "rose",
  "forest",
];
fetch("/api/products")
  .then((r) => r.json())
  .then((d) => {
    S = { ...S, ...d.settings };
    updateSum();
  })
  .catch(() => {});
const fee = (sub) => (sub >= S.freeOver ? 0 : S.deliveryFee),
  subtotal = () => cartDetails().reduce((a, x) => a + x.line.quantity * x.p.price, 0);
/* scroll effects */
addEventListener(
  "scroll",
  () => {
    const h = document.documentElement;
    $("#progress").style.width = (scrollY / (h.scrollHeight - innerHeight)) * 100 + "%";
    $(".site-header").classList.toggle("scrolled", scrollY > 40);
  },
  { passive: true },
);
/* product grid: stagger + quick view */
new MutationObserver(() => {
  $$(".product-card").forEach((c, i) => {
    if (c.dataset.b) return;
    c.dataset.b = 1;
    c.style.setProperty("--i", i);
    const id = c.querySelector("[data-add]")?.dataset.add,
      p = products.find((x) => x.id === id);
    if (p && p.stock < 1) c.classList.add("soldout");
    c.onclick = (e) => {
      if (!e.target.closest("[data-add]")) quick(id);
    };
  });
}).observe($("#productGrid"), { childList: true });
function quick(id) {
  const p = products.find((x) => x.id === id);
  if (!p) return;
  const av = (z) => ((p.sizeStock || {})[z] ?? p.stock) > 0;
  let size = p.sizes.includes("M") && av("M") ? "M" : p.sizes.find(av) || "";
  const low = p.stock > 0 && p.stock < 8;
  $("#quickBody").innerHTML =
    `<div class="qv"><img src="${IMG(p.photo)}" alt="${esc(p.color)} scrub set"><div><p class="eyebrow">${esc(p.category.toUpperCase())} · UNISEX</p><h3>${esc(p.name)}</h3><b>${money(p.price)}</b><p>${esc(p.description)}</p><div class="sizes">${p.sizes.map((s) => `<button data-sz="${s}" class="${s === size ? "on" : ""}${av(s) ? "" : " out"}" ${av(s) ? "" : 'disabled title="Sold out in this size"'}>${s}</button>`).join("")}</div><div class="stockline" id="slx"></div><button class="text-link" data-guide="${id}" style="background:none;border:0;cursor:pointer;margin:0 0 14px;padding:0">SIZE GUIDE · FIND MY SIZE &nbsp;↗</button><br><button class="button button-dark" id="qvAdd" ${p.stock < 1 ? "disabled" : ""}>Add to bag &nbsp;↗</button></div></div>`;
  const upd = () => {
    const n = size ? ((p.sizeStock || {})[size] ?? p.stock) : 0,
      e = $("#slx");
    e.className = "stockline" + (n > 0 && n < 4 ? "" : " ok");
    e.textContent = !size
      ? "SOLD OUT"
      : n < 4
        ? `ONLY ${n} LEFT IN SIZE ${size}`
        : "IN STOCK · SHIPS IN 1–2 DAYS";
    $("#qvAdd").disabled = !size;
  };
  upd();
  $$("[data-sz]").forEach(
    (b) =>
      (b.onclick = () => {
        size = b.dataset.sz;
        $$("[data-sz]").forEach((x) => x.classList.toggle("on", x === b));
        upd();
      }),
  );
  $("[data-guide]").onclick = () => guide(id);
  $("#qvAdd").onclick = () => {
    addToCart(id, size);
    closeLayers();
    toggleLayer($("#cartDrawer"));
  };
  toggleLayer($("#quickModal"));
}
addToCart = function (id, size = "M") {
  const p = products.find((x) => x.id === id);
  if (!p) return;
  if (p.stock < 1) return notice("Sorry, this set is sold out.");
  const f = cart.find((x) => x.id === id);
  if (f) {
    f.size = size;
    f.quantity = Math.min(f.quantity + 1, p.stock);
  } else cart.push({ id, size, quantity: 1 });
  persistCart();
  notice(`${p.name} (${size}) added to your bag.`);
  const b = $("#cartOpen");
  b.classList.remove("bump");
  void b.offsetWidth;
  b.classList.add("bump");
};
/* cart + checkout summary */
function updateSum() {
  const sub = subtotal(),
    f = fee(sub),
    left = Math.max(0, S.freeOver - sub);
  const n = $(".delivery-note");
  if (n)
    n.innerHTML = left
      ? `✳ &nbsp; Add <b>${money(left)}</b> more for free delivery`
      : "✳ &nbsp; You’ve unlocked <b>free delivery</b>";
  let s = $("#sumBox");
  if (!s) {
    s = document.createElement("div");
    s.id = "sumBox";
    s.className = "sum";
    $(".checkout-total").before(s);
  }
  s.innerHTML = `<div><span>Subtotal</span><span>${money(sub)}</span></div><div><span>Delivery</span><span>${f ? money(f) : "Free"}</span></div>`;
  $("#checkoutTotal").textContent = money(sub + f);
}
const _rc = renderCart;
renderCart = function () {
  _rc();
  updateSum();
};
updateSum();
const hints = {
  cash: "Pay the courier in cash when your order arrives.",
  card: "You’ll get a secure payment link right after ordering. We never see or store your card details.",
  wallet:
    "Send the total from Vodafone Cash, Orange Cash or Etisalat Cash — details shown after ordering.",
  instapay:
    "Pay instantly with InstaPay from any bank app — the payment address is shown right after ordering.",
  applepay:
    "Pay with Apple Pay on a secure page right after ordering. We never see or store your card details.",
};
$$('[name="payment"]').forEach(
  (r) => (r.onchange = () => ($("#paymentHint").textContent = hints[r.value])),
);
$("#paymentHint").textContent = hints.cash;
if (!$(".steps"))
  $("#checkoutForm").insertAdjacentHTML(
    "afterbegin",
    '<div class="steps"><i class="on"></i><i></i><i></i></div>',
  );
const st = $(".steps");
$("#checkoutForm").addEventListener("input", () => {
  const f = new FormData($("#checkoutForm"));
  const a = f.get("name") && f.get("phone"),
    b = a && f.get("address");
  [...st.children].forEach((x, i) =>
    x.classList.toggle("on", i === 0 || (i === 1 && a) || (i === 2 && b)),
  );
});
$("#checkoutOpen").addEventListener("click", () => {
  try {
    const me = JSON.parse(localStorage.getItem("skrps-me") || "null"),
      f = $("#checkoutForm");
    if (me)
      for (const k of ["name", "phone", "email", "address"])
        if (f.elements[k] && !f.elements[k].value) f.elements[k].value = me[k] || "";
  } catch (_) {}
});
const orderText = (o) =>
  [
    `New order ${o.id}`,
    `Name: ${o.customer.name}`,
    `Phone: ${o.customer.phone}`,
    `Email: ${o.customer.email}`,
    `Address: ${o.customer.address}`,
    "",
    ...o.items.map(
      (i) =>
        `${i.quantity}x ${i.name} (${i.color}, size ${i.size}) - ${money(i.unitPrice * i.quantity)}`,
    ),
    "",
    `Delivery: ${o.delivery ? money(o.delivery) : "Free"}`,
    `Total: ${money(o.total)}`,
    `Payment: ${o.paymentMethod}`,
  ].join("\n");
const waNum = (n) => {
  let s = String(n || "").replace(/\D/g, "");
  if (s.startsWith("0")) s = "2" + s;
  return s;
};
$("#checkoutForm").onsubmit = async (e) => {
  e.preventDefault();
  const f = new FormData(e.target),
    btn = e.submitter || $(".place-order"),
    v = {
      name: String(f.get("name") || "").trim(),
      phone: String(f.get("phone") || "").trim(),
      email: String(f.get("email") || "").trim(),
      address: String(f.get("address") || "").trim(),
    };
  if (v.name.length < 2) return notice("Please enter your full name.");
  if (!/^(\+?20|0)?1[0125]\d{8}$/.test(v.phone.replace(/[\s-]/g, "")))
    return notice("Please enter a valid Egyptian mobile number.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email))
    return notice("Please enter a valid email address.");
  if (v.address.length < 8)
    return notice("Please enter your full delivery address: street, area and city.");
  if (!cart.length) return notice("Your bag is empty.");
  btn.disabled = true;
  btn.textContent = "Placing your order…";
  try {
    const r = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer: v,
        paymentMethod: f.get("payment"),
        items: cart.map((x) => ({ ...x })),
      }),
    });
    const d = await r.json();
    if (!r.ok) throw Error(d.error);
    const o = d.order;
    try {
      localStorage.setItem("skrps-me", JSON.stringify(v));
    } catch (_) {}
    cart = [];
    persistCart();
    e.target.reset();
    loadStore();
    const pay =
      o.paymentMethod === "cash"
        ? `Please have <code>${money(o.total)}</code> ready for the courier.`
        : o.paymentMethod === "applepay"
          ? o.applepayUrl
            ? `<a class="button button-dark" href="${esc(o.applepayUrl)}" target="_blank" rel="noopener">Pay ${money(o.total)} with Apple Pay &nbsp;↗</a>`
            : `We’ll message you a secure Apple Pay link shortly.`
          : o.paymentMethod === "instapay"
          ? `Send <code>${money(o.total)}</code> by InstaPay to <code>${esc(o.instapayHandle || o.walletNumber || "—")}</code> and write <code>${esc(o.id)}</code> in the reference. ${o.instapayLink ? `<br><a class="button button-dark" style="margin-top:10px" href="${esc(o.instapayLink)}" target="_blank" rel="noopener">Open InstaPay &nbsp;↗</a><br>` : ""}We’ll confirm once received.`
          : o.paymentMethod === "wallet"
          ? `Send <code>${money(o.total)}</code> to wallet <code>${esc(o.walletNumber)}</code> and use <code>${esc(o.id)}</code> as the reference. We’ll confirm once received.`
          : o.cardUrl
            ? `<a class="button button-dark" href="${esc(o.cardUrl)}" target="_blank" rel="noopener">Pay ${money(o.total)} by card &nbsp;↗</a>`
            : `We’ll message you a secure card payment link shortly.`;
    const first = esc(v.name.split(" ")[0]);
    if (o.saved) {
      $("#quickBody").innerHTML =
        `<div class="done"><div class="tick">✓</div><p class="eyebrow">ORDER CONFIRMED</p><h3 style="font:500 30px var(--display);margin:0">Thank you, ${first}!</h3><div class="box">Order <code>${esc(o.id)}</code><br>${pay}</div><p style="font-size:11px;color:#777">We’ll call you on ${esc(v.phone)} to confirm delivery.</p><button class="button button-dark" data-close2>Keep shopping</button></div>`;
    } else {
      const txt = orderText(o),
        n = waNum(o.whatsapp);
      $("#quickBody").innerHTML =
        `<div class="done"><div class="tick">!</div><p class="eyebrow">ONE LAST STEP</p><h3 style="font:500 28px var(--display);margin:0">${first}, send us your order</h3><div class="box">We could not reach the store’s order system from this device, so your order is <b>not confirmed yet</b>. Send it to us and we’ll confirm it.<br>${n ? `<a class="button button-dark" style="margin-top:12px" href="https://wa.me/${n}?text=${encodeURIComponent(txt)}" target="_blank" rel="noopener">Send on WhatsApp &nbsp;↗</a>` : `<textarea id="ordTxt" readonly rows="9" style="width:100%;margin-top:10px;font:12px/1.5 monospace">${esc(txt)}</textarea><button class="button button-dark" style="margin-top:10px" id="ordCopy">Copy order details</button>`}</div><button class="button" data-close2>Keep shopping</button></div>`;
      const cb = $("#ordCopy");
      if (cb)
        cb.onclick = () => {
          const t = $("#ordTxt");
          t.select();
          (navigator.clipboard ? navigator.clipboard.writeText(txt) : Promise.reject())
            .catch(() => document.execCommand && document.execCommand("copy"))
            .then(
              () => notice("Copied."),
              () => notice("Select the text and copy it."),
            );
        };
    }
    closeLayers();
    toggleLayer($("#quickModal"));
    $("[data-close2]").onclick = closeLayers;
  } catch (err) {
    notice(err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = "Place your order &nbsp; ↗";
  }
};

/* ================= ADMIN DASHBOARD ================= */
const TABS = [
  ["overview", "▦", "Overview"],
  ["orders", "☰", "Orders"],
  ["products", "◧", "Products"],
  ["customers", "☺", "Customers"],
  ["settings", "⚙", "Settings"],
];
const dd = (s) => new Date(s).toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
const STAT = ["New", "Processing", "Shipped", "Delivered", "Cancelled"];
renderDashboard = function () {
  const d = adminData;
  $("#dashboard").innerHTML =
    `<nav class="side"><a class="wordmark">skrps<span>®</span></a>${TABS.map((t) => `<button data-tab="${t[0]}" class="${t[0] === tab ? "on" : ""}"><span>${t[1]}</span>${t[2]}</button>`).join("")}<div class="sp"></div><button data-act="refresh">↻ Refresh</button><button data-act="exit">← Back to shop</button><button data-act="logout">Sign out</button></nav><div class="main">${d.persistent === false ? '<div class="card" style="background:#fff3cd;border:1px solid #e6c85a"><b>⚠ Temporary demo storage.</b> <span style="font-size:12px">Orders and edits can disappear. Connect a free Turso database (see README) to keep them permanently.</span></div>' : ""}${VIEWS[tab](d)}<p class="legal">© 2026 <a href="https://binarybyte.vercel.app" target="_blank" rel="noopener">BinaryByte</a>. All rights reserved.</p></div>`;
};
const rev = (o) => o.filter((x) => x.status !== "Cancelled");
const VIEWS = {
  overview(d) {
    const o = d.orders,
      ok = rev(o),
      gross = ok.reduce((n, x) => n + x.total, 0),
      days = [...Array(7)].map((_, i) => {
        const t = new Date();
        t.setDate(t.getDate() - 6 + i);
        return t.toDateString();
      }),
      by = days.map((k) =>
        ok
          .filter((x) => new Date(x.createdAt).toDateString() === k)
          .reduce((n, x) => n + x.total, 0),
      ),
      mx = Math.max(...by, 1);
    const pm = ["cash", "card", "wallet", "instapay", "applepay"].map((m) => [
        m,
        o.filter((x) => x.paymentMethod === m).length,
      ]),
      sold = {};
    ok.forEach((x) => x.items.forEach((i) => (sold[i.name] = (sold[i.name] || 0) + i.quantity)));
    const top = Object.entries(sold)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5),
      low = d.products.filter((p) => p.stock < 8);
    return `<h2>Overview</h2><div class="metric-grid"><div class="metric"><span>REVENUE</span><b>${money(gross)}</b></div><div class="metric"><span>ORDERS</span><b>${o.length}</b></div><div class="metric"><span>TO FULFIL</span><b>${o.filter((x) => ["New", "Processing"].includes(x.status)).length}</b></div><div class="metric"><span>AVG. ORDER</span><b>${money(ok.length ? Math.round(gross / ok.length) : 0)}</b></div></div>
<div class="two"><div class="card"><h3>Revenue · last 7 days</h3><div class="bars">${by.map((v, i) => `<div><span style="height:${(v / mx) * 100}%" title="${money(v)}"></span>${dd(days[i])}</div>`).join("")}</div></div><div class="card"><h3>Payment methods</h3>${pm.map(([m, n]) => `<p style="font-size:12px;display:flex;justify-content:space-between"><b>${m.toUpperCase()}</b><span>${n}</span></p>`).join("")}<h3 style="margin-top:18px">Best sellers</h3>${top.map(([n, q]) => `<p style="font-size:11px;display:flex;justify-content:space-between"><span>${esc(n)}</span><b>${q}</b></p>`).join("") || "<small>No sales yet.</small>"}</div></div>
<div class="card"><h3>⚠ Low stock (${low.length})</h3>${low.map((p) => `<span class="pill" style="margin:3px;display:inline-block">${esc(p.name)} · ${p.stock}</span>`).join("") || "<small>All stocked up.</small>"}</div>`;
  },
  orders(d) {
    const L = d.orders.filter(
      (o) =>
        (of === "all" || o.status === of) &&
        (o.id + o.customer.name + o.customer.phone).toLowerCase().includes(oq.toLowerCase()),
    );
    return `<h2>Orders</h2><div class="card"><div class="form"><label>SEARCH<input id="oq" value="${esc(oq)}" placeholder="ID, name, phone"></label><label>STATUS<select id="of"><option value="all">All</option>${STAT.map((s) => `<option ${s === of ? "selected" : ""}>${s}</option>`).join("")}</select></label><button class="sb g" data-act="csv">⬇ Export CSV</button></div><div style="overflow:auto;margin-top:14px"><table class="tbl"><thead><tr><th>ORDER</th><th>DATE</th><th>CUSTOMER</th><th>ITEMS</th><th>TOTAL</th><th>PAYMENT</th><th>STATUS</th></tr></thead><tbody>${L.map((o) => `<tr><td><b>${esc(o.id)}</b></td><td>${dd(o.createdAt)}</td><td>${esc(o.customer.name)}${o.accountId ? ' <span class="pill Delivered">ACCOUNT</span>' : ""}<br><small>${esc(o.customer.phone)}</small><br><small>${esc(o.customer.email || "")}</small><br><small>${esc(o.customer.address)}</small></td><td>${o.items.map((i) => `${i.quantity}× ${esc(i.name)} (${esc(i.size)})`).join("<br>")}</td><td>${money(o.total)}</td><td>${o.paymentMethod.toUpperCase()}<br><small>${esc(o.paymentStatus)}</small>${o.paymentStatus === "Awaiting payment" ? `<br><button class="sb g" data-paid="${esc(o.id)}">Mark paid</button>` : ""}</td><td><select class="status-select" data-status="${esc(o.id)}">${STAT.map((s) => `<option ${s === o.status ? "selected" : ""}>${s}</option>`).join("")}</select></td></tr>`).join("") || '<tr><td colspan="7">No orders match.</td></tr>'}</tbody></table></div></div>`;
  },
  products(d) {
    return `<h2>Products</h2><div class="card"><h3>Add a product</h3><form class="form" id="addP"><label>NAME<input name="name" required></label><label>COLOUR<input name="color" required></label><label>HEX<input name="hex" type="color" value="#176e61"></label><label>PRICE<input name="price" type="number" min="1" value="${S.flatPrice || 1500}" required></label><label>STOCK<input name="stock" type="number" min="0" value="20"></label><label>FIT<select name="category"><option>Classic fit</option><option>Tailored fit</option></select></label><label>IMAGE<select name="photo">${PHOTOS.map((p) => `<option>${p}.jpeg</option>`).join("")}</select></label><button class="sb">+ Add</button></form></div>
<div class="card" style="overflow:auto"><table class="tbl"><thead><tr><th>PRODUCT</th><th>PRICE</th><th>STOCK</th><th>STATUS</th><th></th></tr></thead><tbody>${d.products.map((p) => `<tr><td><div class="ptile"><img src="${IMG(p.photo)}" alt=""><div><input data-f="name" data-id="${esc(p.id)}" value="${esc(p.name)}"><br><small>${esc(p.color)} · ${esc(p.category)}</small></div></div></td><td><input data-f="price" data-id="${esc(p.id)}" type="number" min="1" value="${p.price}" style="width:90px"></td><td><div class="szgrid">${p.sizes.map((z) => `<label>${z}<input type="number" min="0" data-szs="${esc(p.id)}" data-z="${z}" value="${(p.sizeStock || {})[z] ?? 0}"></label>`).join("")}</div><small>Total in stock: <b>${p.stock}</b></small></td><td><span class="pill ${p.active === false ? "Cancelled" : "Delivered"}">${p.active === false ? "HIDDEN" : "LIVE"}</span></td><td><button class="sb g" data-active="${esc(p.id)}">${p.active === false ? "Restore" : "Hide"}</button> <button class="sb r" data-del="${esc(p.id)}">Delete</button></td></tr>`).join("")}</tbody></table></div>`;
  },
  customers(d) {
    const m = {};
    d.orders.forEach((o) => {
      const c = (m[o.customer.phone] ??= {
        name: o.customer.name,
        phone: o.customer.phone,
        email: o.customer.email,
        address: o.customer.address,
        n: 0,
        sum: 0,
        last: o.createdAt,
      });
      c.n++;
      if (o.status !== "Cancelled") c.sum += o.total;
    });
    const L = Object.values(m).sort((a, b) => b.sum - a.sum);
    return `<h2>Customers</h2><div class="card" style="overflow:auto"><table class="tbl"><thead><tr><th>NAME</th><th>PHONE</th><th>EMAIL</th><th>ADDRESS</th><th>ORDERS</th><th>SPENT</th><th>LAST ORDER</th></tr></thead><tbody>${L.map((c) => `<tr><td>${esc(c.name)}${c.n > 1 ? ' <span class="pill Delivered">REPEAT</span>' : ""}</td><td><a href="tel:${esc(c.phone)}">${esc(c.phone)}</a></td><td>${esc(c.email || "—")}</td><td>${esc(c.address || "—")}</td><td>${c.n}</td><td>${money(c.sum)}</td><td>${dd(c.last)}</td></tr>`).join("") || '<tr><td colspan="7">No customers yet.</td></tr>'}</tbody></table></div>`;
  },
  settings(d) {
    const s = d.settings;
    return `<h2>Settings</h2><div class="card"><h3>Storefront</h3><form class="form" id="setF"><label>ANNOUNCEMENT BAR<input name="announcement" value="${esc(s.announcement)}" maxlength="180"></label><label>PRICE FOR ALL SETS · EGP<input name="flatPrice" type="number" min="1" value="${s.flatPrice}"></label><label>DELIVERY FEE · EGP<input name="deliveryFee" type="number" min="0" value="${s.deliveryFee ?? 80}"></label><label>FREE DELIVERY OVER · EGP<input name="freeOver" type="number" min="0" value="${s.freeOver ?? 3000}"></label></form></div><div class="card"><h3>Payments</h3><form class="form" id="setP"><label>WHATSAPP NUMBER (shows a chat button on the shop)<input name="whatsapp" value="${esc(s.whatsapp || "")}" placeholder="01XXXXXXXXX"></label><label>CONTACT EMAIL (shown in the shop footer)<input name="contactEmail" type="email" value="${esc(s.contactEmail || "")}" placeholder="hello@yourshop.com"></label><label>WALLET NUMBER (shown to customers)<input name="walletNumber" value="${esc(s.walletNumber || "")}"></label><label>INSTAPAY ADDRESS / NUMBER (shown to customers, e.g. name@instapay)<input name="instapayHandle" value="${esc(s.instapayHandle || "")}" placeholder="name@instapay"></label><label>INSTAPAY PAYMENT LINK (optional)<input name="instapayLink" value="${esc(s.instapayLink || "")}" placeholder="https://ipn.eg/…"></label><label>APPLE PAY PAYMENT LINK (hosted checkout page that supports Apple Pay)<input name="applepayUrl" value="${esc(s.applepayUrl || "")}" placeholder="https://…"></label><label>CARD PAYMENT LINK (Paymob / Fawry / Stripe hosted link)<input name="cardUrl" value="${esc(s.cardUrl || "")}" placeholder="https://…"></label></form><p style="font-size:10px;color:#777">Cards are paid on your provider’s hosted page — this site never handles card numbers.</p><button class="sb" data-act="saveSet">Save all settings</button></div>`;
  },
};
async function adm(path, method, body) {
  try {
    const r = await fetchAdmin(path, { method, body: body && JSON.stringify(body) });
    return r;
  } catch (e) {
    notice(e.message);
    throw e;
  }
}
const reload = async (m) => {
  await loadDashboard();
  await loadStore();
  if (m) notice(m);
};
$("#dashboard").addEventListener("click", async (e) => {
  const t = e.target.closest("button");
  if (!t) return;
  const a = t.dataset;
  if (a.tab) {
    tab = a.tab;
    renderDashboard();
  } else if (a.act === "refresh") reload("Refreshed.");
  else if (a.act === "exit") closeLayers();
  else if (a.act === "logout") {
    adminKey = "";
    sessionStorage.removeItem("skrps-admin");
    $("#adminLogin").hidden = false;
    $("#dashboard").hidden = true;
  } else if (a.act === "csv") {
    const q = (c) => `"${String(c ?? "").replace(/"/g, '""')}"`,
      rows = [
        [
          "id",
          "date",
          "name",
          "phone",
          "email",
          "address",
          "items",
          "total",
          "payment",
          "payment status",
          "status",
        ],
        ...adminData.orders.map((o) => [
          o.id,
          o.createdAt,
          o.customer.name,
          o.customer.phone,
          o.customer.email,
          o.customer.address,
          o.items.map((i) => i.quantity + "x " + i.name + " (" + i.size + ")").join("; "),
          o.total,
          o.paymentMethod,
          o.paymentStatus,
          o.status,
        ]),
      ],
      csv = "\ufeff" + rows.map((r) => r.map(q).join(",")).join("\n"),
      u = URL.createObjectURL(new Blob([csv], { type: "text/csv" })),
      l = document.createElement("a");
    l.href = u;
    l.download = "orders.csv";
    document.body.appendChild(l);
    l.click();
    l.remove();
    setTimeout(() => URL.revokeObjectURL(u), 2000);
  } else if (a.act === "saveSet") {
    const b = {
      ...Object.fromEntries(new FormData($("#setF"))),
      ...Object.fromEntries(new FormData($("#setP"))),
    };
    await adm("/api/admin/settings", "PATCH", b);
    await reload("Settings saved.");
  } else if (a.paid) {
    await adm("/api/admin/orders/" + encodeURIComponent(a.paid), "PATCH", {
      status: "Processing",
      paymentStatus: "Paid",
    });
    await reload("Marked as paid.");
  } else if (a.active) {
    const p = adminData.products.find((x) => x.id === a.active);
    await adm("/api/admin/products/" + a.active, "PATCH", { active: p.active === false });
    await reload("Product updated.");
  } else if (a.del && (await ask("Delete this product permanently?"))) {
    await adm("/api/admin/products/" + a.del, "DELETE");
    await reload("Product deleted.");
  }
});
$("#dashboard").addEventListener("change", async (e) => {
  const t = e.target,
    a = t.dataset;
  if (a.status) {
    await adm("/api/admin/orders/" + encodeURIComponent(a.status), "PATCH", {
      status: t.value,
    });
    await reload("Order status updated.");
  } else if (a.f) {
    await adm("/api/admin/products/" + a.id, "PATCH", { [a.f]: t.value });
    await reload("Saved.");
  } else if (a.szs) {
    const o = {};
    $$("[data-szs]").forEach((i) => {
      if (i.dataset.szs === a.szs) o[i.dataset.z] = +i.value || 0;
    });
    await adm("/api/admin/products/" + a.szs, "PATCH", { sizeStock: o });
    await reload("Stock saved.");
  } else if (t.id === "of") {
    of = t.value;
    renderDashboard();
  }
});
$("#dashboard").addEventListener("input", (e) => {
  if (e.target.id === "oq") {
    oq = e.target.value;
    const p = e.target.selectionStart;
    renderDashboard();
    const i = $("#oq");
    i.focus();
    i.setSelectionRange(p, p);
  }
});
$("#dashboard").addEventListener("submit", async (e) => {
  e.preventDefault();
  if (e.target.id === "addP") {
    await adm("/api/admin/products", "POST", Object.fromEntries(new FormData(e.target)));
    await reload("Product added to the shop.");
  }
});

/* ===== v3: sizes, colour story, stats, tilt ===== */
const CHART = [
  ["XS", "84–89", "66", "XS"],
  ["S", "90–95", "68", "S"],
  ["M", "96–102", "70", "M"],
  ["L", "103–110", "72", "L"],
  ["XL", "111–118", "74", "XL"],
  ["XXL", "119–127", "76", "XXL"],
];
function pick(h, w) {
  const L = ["XS", "S", "M", "L", "XL", "XXL"];
  let i = w < 55 ? 0 : w < 65 ? 1 : w < 75 ? 2 : w < 87 ? 3 : w < 100 ? 4 : 5;
  if (h > 185) i++;
  if (h && h < 155) i--;
  return L[Math.max(0, Math.min(5, i))];
}
function guide(back) {
  $("#quickBody").innerHTML =
    `<p class="eyebrow">SIZE GUIDE · UNISEX FIT</p><h3 style="font:500 30px var(--display);margin:0 0 6px">Find your <em style="font-family:var(--serif)">size.</em></h3><div class="finder"><label>HEIGHT · CM<input id="gh" type="number" min="120" max="220" placeholder="170"></label><label>WEIGHT · KG<input id="gw" type="number" min="30" max="200" placeholder="68"></label><button class="sb" id="gb">Suggest</button></div><div class="rec" id="rec">Enter your height and weight for a suggested size.</div><table class="gtbl"><tr><th>SIZE</th><th>CHEST (CM)</th><th>TOP LENGTH (CM)</th></tr>${CHART.map((r) => `<tr data-r="${r[0]}"><td><b>${r[0]}</b></td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join("")}</table><p style="font-size:10px;color:#777">Sizes are a guide. Between two sizes? Choose the larger for a relaxed fit.</p>${back ? `<button class="button button-dark" id="gback">← Back to the set</button>` : ""}`;
  $("#gb").onclick = () => {
    const h = +$("#gh").value,
      w = +$("#gw").value;
    if (!w) return notice("Please enter your weight.");
    const z = pick(h, w);
    $("#rec").innerHTML = `We suggest size <b>${z}</b>`;
    $$(".gtbl tr[data-r]").forEach((r) => r.classList.toggle("hit", r.dataset.r === z));
  };
  if (back)
    $("#gback").onclick = () => {
      closeLayers();
      quick(back);
    };
  if (!$("#quickModal").classList.contains("open")) {
    closeLayers();
    toggleLayer($("#quickModal"));
  }
}
$(".main-nav").insertAdjacentHTML("beforeend", '<a href="#" data-guide-nav>Size guide</a>');
$("[data-guide-nav]").onclick = (e) => {
  e.preventDefault();
  guide();
};
/* cart with multiple sizes per product */
addToCart = function (id, size = "M") {
  const p = products.find((x) => x.id === id);
  if (!p) return;
  if (p.stock < 1) return notice("Sorry, this set is sold out.");
  const f = cart.find((x) => x.id === id && x.size === size);
  const cap = (p.sizeStock || {})[size] ?? p.stock;
  if (cap < 1) return notice(`Size ${size} is sold out.`);
  if (f) f.quantity = Math.min(f.quantity + 1, cap);
  else cart.push({ id, size, quantity: 1 });
  persistCart();
  notice(`${p.name} (${size}) added to your bag.`);
  const b = $("#cartOpen");
  b.classList.remove("bump");
  void b.offsetWidth;
  b.classList.add("bump");
};
renderCart = function () {
  const L = cartDetails(),
    n = L.reduce((a, x) => a + x.line.quantity, 0),
    t = subtotal();
  $("#cartCount").textContent = n;
  $("#bagHeadingCount").textContent = `(${n})`;
  $("#cartSubtotal").textContent = money(t);
  $("#cartEmpty").style.display = L.length ? "none" : "block";
  $("#cartFoot").style.display = L.length ? "block" : "none";
  $("#cartItems").innerHTML = L.map(
    ({ line, p }) =>
      `<div class="cart-line"><div class="cart-thumb"><img class="product-photo" src="${IMG(p.photo)}" alt="${esc(p.color)}"></div><div><div class="cart-line-title">${esc(p.name)}</div><div class="cart-line-meta">${esc(p.color)}</div><div class="sizechip"><select data-sz2="${esc(p.id)}|${esc(line.size)}" aria-label="Size">${p.sizes.map((z) => `<option ${z === line.size ? "selected" : ""}>${z}</option>`).join("")}</select></div><div class="qty-control"><button data-k="${esc(p.id)}|${esc(line.size)}" data-d="-1" aria-label="Less">−</button>${line.quantity}<button data-k="${esc(p.id)}|${esc(line.size)}" data-d="1" aria-label="More">+</button><button class="remove-item" data-rm="${esc(p.id)}|${esc(line.size)}">REMOVE</button></div></div><span class="cart-line-price">${money(line.quantity * p.price)}</span></div>`,
  ).join("");
  const K = (k) => {
    const [i, z] = k.split("|");
    return cart.find((x) => x.id === i && x.size === z);
  };
  $$("[data-k]").forEach(
    (b) =>
      (b.onclick = () => {
        const x = K(b.dataset.k);
        x.quantity += +b.dataset.d;
        if (x.quantity < 1) cart = cart.filter((i) => i !== x);
        persistCart();
      }),
  );
  $$("[data-rm]").forEach(
    (b) =>
      (b.onclick = () => {
        cart = cart.filter((i) => i !== K(b.dataset.rm));
        persistCart();
      }),
  );
  $$("[data-sz2]").forEach(
    (s) =>
      (s.onchange = () => {
        const x = K(s.dataset.sz2),
          dup = cart.find((i) => i !== x && i.id === x.id && i.size === s.value);
        if (dup) {
          dup.quantity += x.quantity;
          cart = cart.filter((i) => i !== x);
        } else x.size = s.value;
        persistCart();
      }),
  );
  updateSum();
};
renderCart();
/* ===== hero stage: colour swatches, big logo and the product on a tinted backdrop ===== */
function hexToHsl(hex) {
  const n = parseInt(hex.replace("#", ""), 16),
    r = ((n >> 16) & 255) / 255,
    g = ((n >> 8) & 255) / 255,
    b = (n & 255) / 255,
    mx = Math.max(r, g, b),
    mn = Math.min(r, g, b),
    l = (mx + mn) / 2,
    d = mx - mn;
  let h = 0,
    s = 0;
  if (d) {
    s = d / (1 - Math.abs(2 * l - 1));
    h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    h = (h * 60 + 360) % 360;
  }
  return [h, s, l];
}
const stage = { list: [], i: 0, timer: null, paused: false };
const NUM_WORDS = [
  "",
  "One",
  "Two",
  "Three",
  "Four",
  "Five",
  "Six",
  "Seven",
  "Eight",
  "Nine",
  "Ten",
  "Eleven",
  "Twelve",
];
function paintStage(i) {
  const p = stage.list[i] || stage.list[0];
  if (!p) return;
  stage.i = stage.list.indexOf(p);
  const [h, s, l] = hexToHsl(p.hex || "#888888"),
    light = l > 0.7,
    bgL = light ? 0.78 : 0.87,
    bgS = Math.min(Math.max(s, 0.3), 0.5) * 100,
    el = $("#stage");
  el.style.setProperty("--tint", `hsl(${h} ${bgS}% ${bgL * 100}%)`);
  el.style.setProperty("--logo", `hsl(${h} ${bgS}% ${Math.min(bgL + 0.1, 0.97) * 100}%)`);
  const img = $("#stageProduct"),
    base = String(p.photo || "").replace(/\.jpe?g$/, "");
  img.classList.remove("in");
  const show = () => {
    img.alt = `${p.color} scrub set`;
    void img.offsetWidth;
    img.classList.add("in");
  };
  img.onload = show;
  img.onerror = () => {
    img.onerror = null;
    img.src = IMG(p.photo);
  };
  img.src = `/img/cut-${base}.png`;
  if (img.complete && img.naturalWidth) show();
  $("#stageColour").textContent = p.color.toUpperCase();
  const n = stage.list.length;
  $("#stageLine").textContent =
    `${NUM_WORDS[n] || n} colours for every shift. The same easy-care fabric in each.`;
  $("#stageCta").innerHTML = `Shop ${esc(p.color)} <span>→</span>`;
  if (el.classList.contains("custom")) {
    $("#stageLine").textContent = `${NUM_WORDS[n] || n} colours for every shift. The same easy-care fabric in each.`;
    $("#stageCta").innerHTML = "Shop the collection <span>→</span>";
  }
  $$("#stageSwatches button").forEach((b, k) => {
    b.classList.toggle("on", k === stage.i);
    b.setAttribute("aria-pressed", k === stage.i);
  });
}
function startStage() {
  clearInterval(stage.timer);
  if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  stage.timer = setInterval(() => {
    if (!stage.paused && !document.hidden && !$("#stage").classList.contains("custom"))
      paintStage((stage.i + 1) % stage.list.length);
  }, 4500);
}
function syncStage() {
  const list = products.filter((p) => p.photo);
  if (!list.length) return;
  const same = list.map((p) => p.id).join() === stage.list.map((p) => p.id).join();
  stage.list = list;
  const filter = $("#colourFilter");
  if (filter && filter.options.length !== new Set(products.map((p) => p.color)).size + 1) {
    const keep = filter.value;
    filter.innerHTML =
      '<option value="all">ALL COLOURS</option>' +
      [...new Set(products.map((p) => p.color))]
        .map((c) => `<option value="${esc(c)}">${esc(c.toUpperCase())}</option>`)
        .join("");
    filter.value = [...filter.options].some((o) => o.value === keep) ? keep : "all";
  }
  if (same) return;
  $("#stageSwatches").innerHTML = list
    .map(
      (p, k) =>
        `<li><button type="button" data-k="${k}" style="background:${esc(p.hex)}" aria-label="${esc(p.color)}" title="${esc(p.color)}"></button></li>`,
    )
    .join("");
  list.forEach((p) => {
    new Image().src = `/img/cut-${String(p.photo).replace(/\.jpe?g$/, "")}.png`;
  });
  paintStage(Math.min(stage.i, list.length - 1));
  startStage();
}
$("#stageSwatches").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-k]");
  if (!b) return;
  paintStage(+b.dataset.k);
  startStage();
});
$("#stage").addEventListener("mouseenter", () => (stage.paused = true));
$("#stage").addEventListener("mouseleave", () => (stage.paused = false));
$("#stageCta").addEventListener("click", () => {
  const p = stage.list[stage.i],
    f = $("#colourFilter");
  if (p && f && [...f.options].some((o) => o.value === p.color)) {
    f.value = p.color;
    f.dispatchEvent(new Event("change"));
  }
});
const _renderProducts = renderProducts;
renderProducts = function () {
  _renderProducts();
  syncStage();
};
syncStage();
/* stats strip with count-up */
$(".ticker").insertAdjacentHTML(
  "afterend",
  '<section class="stats"><div><b data-n="9">0</b><span>COLOURS</span></div><div><b data-n="6">0</b><span>SIZES · XS TO XXL</span></div><div><b data-n="1500">0</b><span>EGP · ONE FAIR PRICE</span></div><div><b data-n="3">0</b><span>WAYS TO PAY</span></div></section>',
);
new IntersectionObserver(
  (es, o) =>
    es.forEach((e) => {
      if (!e.isIntersecting) return;
      o.unobserve(e.target);
      $$("[data-n]").forEach((b) => {
        const T = +b.dataset.n,
          t0 = performance.now();
        (function f(t) {
          const k = Math.min(1, (t - t0) / 1400);
          b.textContent = Math.round(T * (1 - Math.pow(1 - k, 3))).toLocaleString();
          if (k < 1) requestAnimationFrame(f);
        })(t0);
      });
    }),
  { threshold: 0.4 },
).observe($(".stats"));
/* 3D tilt on product cards */
$("#productGrid").addEventListener("mousemove", (e) => {
  const v = e.target.closest(".product-visual");
  if (!v) return;
  const r = v.getBoundingClientRect();
  v.style.setProperty("--ry", ((e.clientX - r.left) / r.width - 0.5) * 10 + "deg");
  v.style.setProperty("--rx", (0.5 - (e.clientY - r.top) / r.height) * 8 + "deg");
});
/* private admin entry: add #owner to the address */
/* ===== admin: site text + hero image ===== */
TABS.splice(4, 0, ["content", "✎", "Site text"], ["image", "▣", "Hero image"]);
VIEWS.content = () =>
  `<h2>Site <em>text</em></h2><p style="font-size:12px;color:#687066">Change any wording on the shop page. It is saved to the database as soon as you leave the box.</p><div class="card"><div class="form"><label>SEARCH<input id="tq" placeholder="Find a word"></label></div></div><div class="card">${SK.orig.map((x, i) => `<div class="txrow" data-s="${esc((x.t + " " + x.sec).toLowerCase())}"><small>${esc((x.sec || x.tag).toUpperCase())}</small><textarea data-tx="${i}" rows="${x.t.length > 70 ? 3 : 1}">${esc(SK.cms.texts[i] ?? x.t)}</textarea></div>`).join("")}</div>`;
$("#dashboard").addEventListener("change", async (e) => {
  const i = e.target.dataset.tx;
  if (i == null) return;
  const v = e.target.value.trim(),
    T = { ...SK.cms.texts };
  if (v === SK.orig[i].t) delete T[i];
  else T[i] = v;
  try {
    await adm("/api/admin/texts", "PUT", { texts: T });
    SK.cms.texts = T;
    SK.applyCms();
    notice("Saved.");
  } catch (_) {}
});
$("#dashboard").addEventListener("input", (e) => {
  if (e.target.id !== "tq") return;
  const q = e.target.value.toLowerCase();
  $$(".txrow").forEach((r) => (r.style.display = r.dataset.s.includes(q) ? "" : "none"));
});
VIEWS.image = () =>
  `<h2>Hero <em>image</em></h2><div class="card"><p style="font-size:12px;color:#687066;line-height:1.8">The big picture on the first screen of the shop. Choose any photo and it goes live straight away, replacing the rotating colour showcase. “Back to original” brings the showcase back.</p><div style="max-width:420px;margin:14px 0">${SK.cms.hero ? `<img id="hpv" src="${SK.cms.hero}" style="width:100%;border-radius:16px;display:block;background:#eee" alt="Hero preview">` : `<div style="padding:34px 20px;border-radius:16px;background:#eee;font-size:12px;color:#687066;text-align:center">Original: rotating colour showcase</div>`}</div><input type="file" id="hf" accept="image/*" hidden><button class="sb" data-pick>▣ Choose a new image</button> <button class="sb g" data-hreset>Back to original</button></div>`;
$("#dashboard").addEventListener("click", async (e) => {
  if (e.target.closest("[data-pick]")) $("#hf").click();
  if (e.target.closest("[data-hreset]")) {
    try {
      await adm("/api/admin/hero", "DELETE");
      SK.cms.hero = "";
      SK.applyCms();
      renderDashboard();
      notice("Original image restored.");
    } catch (_) {}
  }
});
$("#dashboard").addEventListener("change", (e) => {
  if (e.target.id !== "hf" || !e.target.files[0]) return;
  const im = new Image(),
    u = URL.createObjectURL(e.target.files[0]);
  im.onload = async () => {
    let s = Math.min(1, 1400 / Math.max(im.width, im.height)),
      q = 0.86,
      d = "";
    const c = document.createElement("canvas");
    for (let k = 0; k < 8; k++) {
      c.width = Math.round(im.width * s);
      c.height = Math.round(im.height * s);
      const cx = c.getContext("2d");
      cx.fillStyle = "#fff";
      cx.fillRect(0, 0, c.width, c.height);
      cx.drawImage(im, 0, 0, c.width, c.height);
      d = c.toDataURL("image/jpeg", q);
      if (d.length < 600000) break;
      q = Math.max(0.5, q - 0.08);
      s *= 0.85;
    }
    URL.revokeObjectURL(u);
    try {
      const r = await adm("/api/admin/hero", "PUT", { data: d });
      SK.cms.hero = r.hero;
      SK.applyCms();
      renderDashboard();
      notice("New image saved.");
    } catch (_) {}
  };
  im.onerror = () => notice("Could not read that image.");
  im.src = u;
});
$("#adminLogin").insertAdjacentHTML(
  "beforeend",
  '<p class="legal">© 2026 <a href="https://binarybyte.vercel.app" target="_blank" rel="noopener">BinaryByte</a>. All rights reserved.</p>',
);

/* ===== admin extras: confirm dialog, auto-save settings, /admin route, live orders, CSV ===== */
window.ask = (msg, okText = "Delete") =>
  new Promise((res) => {
    const w = document.createElement("div");
    w.className = "askbox";
    w.innerHTML = `<div class="askcard" role="alertdialog"><p>${esc(msg)}</p><div><button class="sb g" data-n>Cancel</button><button class="sb r" data-y>${okText}</button></div></div>`;
    document.body.appendChild(w);
    w.onclick = (e) => {
      const y = e.target.dataset.y != null;
      if (y || e.target.dataset.n != null || e.target === w) {
        w.remove();
        res(y);
      }
    };
  });
$("#dashboard").addEventListener("change", async (e) => {
  if (!e.target.closest("#setF,#setP")) return;
  const b = {
    ...Object.fromEntries(new FormData($("#setF"))),
    ...Object.fromEntries(new FormData($("#setP"))),
  };
  try {
    await adm("/api/admin/settings", "PATCH", b);
    await reload("Saved.");
  } catch (_) {}
});
/* "Saved" badge after every change made in the dashboard */
(() => {
  const _f = window.fetch.bind(window);
  let t;
  window.fetch = async (u, o = {}) => {
    const w = String(u).startsWith("/api/admin") && (o.method || "GET") !== "GET";
    if (w) SK.badge("saving", "Saving…");
    try {
      const r = await _f(u, o);
      if (w) {
        clearTimeout(t);
        if (r.ok) {
          SK.badge("ok", "✓ Saved to database");
          t = setTimeout(() => SK.badge("", ""), 2500);
        } else SK.badge("err", "Not saved");
      }
      return r;
    } catch (e) {
      if (w) SK.badge("err", "Not saved: no connection");
      throw e;
    }
  };
})();
const hashAdmin = () => {
  if (false) openAdmin();
};
hashAdmin();
document.addEventListener("click", (e) => {
  if (e.target.closest(".admin-close,[data-act=exit]") && location.pathname.startsWith("/admin"))
    history.replaceState(null, "", "/");
});
/* new orders appear on their own every 10 seconds */
let lastN = -1;
setInterval(async () => {
  if (!$("#adminPanel").classList.contains("open") || $("#dashboard").hidden || document.hidden)
    return;
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return;
  try {
    await loadDashboard();
    const n = adminData.orders.length;
    if (lastN >= 0 && n > lastN) notice("New order received.");
    lastN = n;
  } catch (_) {}
}, 10000);
