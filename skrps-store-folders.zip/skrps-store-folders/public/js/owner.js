/* owner page: open the dashboard straight away */
openAdmin();
