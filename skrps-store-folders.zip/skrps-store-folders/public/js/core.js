/* Skrps Studio — core: storage shim, product images, site-text editing */
const SK = (window.SK = { orig: [], cms: { texts: {}, hero: "" }, applyCms: () => {} });
SK.badge = (k, t) => {
  let b = document.getElementById("saveBadge");
  if (!b) {
    b = document.createElement("div");
    b.id = "saveBadge";
    document.body.appendChild(b);
  }
  b.dataset.st = k;
  b.textContent = t;
  b.hidden = !t;
};

(() => {
  try {
    localStorage.setItem("_t", 1);
    sessionStorage.setItem("_t", 1);
  } catch (e) {
    const m = () => {
      const o = {};
      return {
        getItem: (k) => (k in o ? o[k] : null),
        setItem: (k, v) => {
          o[k] = String(v);
        },
        removeItem: (k) => {
          delete o[k];
        },
      };
    };
    for (const n of ["localStorage", "sessionStorage"]) {
      const s = m();
      Object.defineProperty(window, n, { get: () => s, configurable: true });
    }
  }
})();
const DATA = {
  "aegean.jpeg": "/img/aegean.jpeg",
  "berry.jpeg": "/img/berry.jpeg",
  "cloud.jpeg": "/img/cloud.jpeg",
  "cobalt.jpeg": "/img/cobalt.jpeg",
  "forest.jpeg": "/img/forest.jpeg",
  "midnight.jpeg": "/img/midnight.jpeg",
  "olive.jpeg": "/img/olive.jpeg",
  "rose.jpeg": "/img/rose.jpeg",
  "skrps-colour-reference.jpeg": "/img/skrps-colour-reference.jpeg",
  "slate.jpeg": "/img/slate.jpeg",
};
const IMG = (f) => DATA[f] || DATA["midnight.jpeg"];
const initialProducts = [
  {
    id: "core-set",
    name: "The Core Set",
    category: "Classic fit",
    color: "Midnight",
    hex: "#19243a",
    photo: "midnight.jpeg",
    kind: "unisex",
    badge: "BESTSELLER",
  },
  {
    id: "coast-set",
    name: "The Coast Set",
    category: "Classic fit",
    color: "Aegean",
    hex: "#168496",
    photo: "aegean.jpeg",
    kind: "unisex",
    badge: "NEW COLOUR",
  },
  {
    id: "olive-set",
    name: "The Olive Set",
    category: "Classic fit",
    color: "Olive",
    hex: "#777d58",
    photo: "olive.jpeg",
    kind: "unisex",
  },
  {
    id: "berry-set",
    name: "The Berry Set",
    category: "Tailored fit",
    color: "Berry",
    hex: "#94324b",
    photo: "berry.jpeg",
    kind: "unisex",
    badge: "POPULAR",
  },
  {
    id: "cloud-set",
    name: "The Cloud Set",
    category: "Tailored fit",
    color: "Cloud",
    hex: "#e9dfcb",
    photo: "cloud.jpeg",
    kind: "unisex",
  },
  {
    id: "slate-set",
    name: "The Slate Set",
    category: "Classic fit",
    color: "Slate",
    hex: "#77757c",
    photo: "slate.jpeg",
    kind: "unisex",
  },
  {
    id: "cobalt-set",
    name: "The Cobalt Set",
    category: "Classic fit",
    color: "Cobalt",
    hex: "#2455dc",
    photo: "cobalt.jpeg",
    kind: "unisex",
  },
  {
    id: "rose-set",
    name: "The Rose Set",
    category: "Tailored fit",
    color: "Rose",
    hex: "#d7839a",
    photo: "rose.jpeg",
    kind: "unisex",
    badge: "NEW COLOUR",
  },
  {
    id: "forest-set",
    name: "The Forest Set",
    category: "Tailored fit",
    color: "Forest",
    hex: "#1b5b4c",
    photo: "forest.jpeg",
    kind: "unisex",
  },
].map((p) => ({
  ...p,
  price: 1500,
  sizes: ["XS", "S", "M", "L", "XL", "XXL"],
  description:
    "Soft, breathable fabric made for long shifts. Thoughtful pocketing, a comfortable stretch, and an easy fit that works for everyone.",
  stock: 24,
  active: true,
}));

(() => {
  const S = "script,style,#adminPanel,#productGrid,#cartItems,.legal,select,option,svg,textarea",
    w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT),
    L = [];
  let n;
  while ((n = w.nextNode())) {
    if (n.nodeValue.trim() && !n.parentElement.closest(S)) L.push(n);
  }
  SK.orig = L.map((n) => ({
    t: n.nodeValue.trim(),
    tag: n.parentElement.tagName.toLowerCase(),
    sec: (n.parentElement.closest("section,header,footer,aside,nav,[id]") || {}).id || "",
  }));
  const raw = L.map((n) => n.nodeValue);
  SK.applyCms = () => {
    const c = SK.cms,
      st = document.getElementById("stage"),
      ci = document.getElementById("stageCustom");
    if (st && ci) {
      if (c.hero) {
        if (ci.getAttribute("src") !== c.hero) ci.src = c.hero;
        st.classList.add("custom");
      } else {
        st.classList.remove("custom");
        ci.removeAttribute("src");
      }
      try {
        if (typeof paintStage === "function" && stage.list.length) paintStage(stage.i);
      } catch (_) {}
    }
    L.forEach((n, i) => {
      const v = c.texts[i];
      if (v != null) {
        const m = raw[i].match(/^(\s*)[\s\S]*?(\s*)$/);
        n.nodeValue = m[1] + v + m[2];
      } else n.nodeValue = raw[i];
    });
  };
})();

fetch("/api/cms")
  .then((r) => r.json())
  .then((c) => {
    SK.cms.texts = c.texts || {};
    SK.cms.hero = c.hero || "";
    SK.applyCms();
  })
  .catch(() => {});
