"use strict";
/* Skrps Studio — web server (no external dependencies, needs Node 22.13+) */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const openDb = require("./db.js");

/* settings file: put ADMIN_PASSWORD / PORT in a file called .env next to this script */
try {
  for (const l of fs.readFileSync(path.join(__dirname, ".env"), "utf8").split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch {}
const PORT = +process.env.PORT || 3000;
/* on Vercel there is no default password: the admin stays locked until ADMIN_PASSWORD is set */
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || (process.env.VERCEL ? "" : "11111");
const PUBLIC = path.join(__dirname, "public");
if (ADMIN_PASSWORD === "11111")
  console.warn(
    "\n⚠  Using the default admin password 11111. Set ADMIN_PASSWORD before going live.\n",
  );

/* ---------------- database ---------------- */
const db = openDb();
const SCHEMA = `
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products (id TEXT PRIMARY KEY, pos INTEGER NOT NULL, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY, created_at TEXT NOT NULL, status TEXT NOT NULL,
  payment_method TEXT NOT NULL, payment_status TEXT NOT NULL,
  name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, address TEXT NOT NULL,
  items TEXT NOT NULL, subtotal INTEGER NOT NULL, delivery INTEGER NOT NULL, total INTEGER NOT NULL,
  restocked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS orders_created ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS orders_phone ON orders(phone);
`;
const seed = JSON.parse(fs.readFileSync(path.join(__dirname, "seed.json"), "utf8"));
let ready = null;
const init = () =>
  (ready ||= (async () => {
    await db.exec(SCHEMA);
    if (!(await db.get("SELECT 1 AS x FROM products LIMIT 1")))
      for (const [i, p] of seed.products.entries())
        await db.run("INSERT OR IGNORE INTO products (id,pos,data) VALUES (?,?,?)", [
          p.id,
          i,
          JSON.stringify(p),
        ]);
    await db.run("INSERT OR IGNORE INTO kv (key,value) VALUES ('settings',?)", [
      JSON.stringify(seed.settings),
    ]);
  })().catch((e) => {
    ready = null;
    throw e;
  }));

/* every helper takes an optional executor x (the transaction object inside db.tx) */
const kvGet = async (k, d, x = db) => {
  const r = await x.get("SELECT value FROM kv WHERE key=?", [k]);
  return r ? JSON.parse(r.value) : d;
};
const kvSet = (k, v, x = db) =>
  x.run(
    "INSERT INTO kv (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
    [k, JSON.stringify(v)],
  );
const kvDel = (k, x = db) => x.run("DELETE FROM kv WHERE key=?", [k]);
const getProducts = async (x = db) =>
  (await x.all("SELECT data FROM products ORDER BY pos")).map((r) => JSON.parse(r.data));
const saveProduct = (p, x = db) =>
  x.run("UPDATE products SET data=? WHERE id=?", [JSON.stringify(p), p.id]);
const total = (p) => p.sizes.reduce((a, z) => a + (p.sizeStock[z] || 0), 0);
const withStock = (p) => {
  if (!p.sizeStock) {
    const n = p.sizes.length,
      t = p.stock || 0,
      b = Math.floor(t / n);
    p.sizeStock = {};
    p.sizes.forEach((z, i) => (p.sizeStock[z] = b + (i < t - b * n ? 1 : 0)));
  }
  p.stock = total(p);
  return p;
};
const rowToOrder = (r) => ({
  id: r.id,
  createdAt: r.created_at,
  status: r.status,
  paymentMethod: r.payment_method,
  paymentStatus: r.payment_status,
  customer: { name: r.name, phone: r.phone, email: r.email, address: r.address },
  items: JSON.parse(r.items),
  subtotal: r.subtotal,
  delivery: r.delivery,
  total: r.total,
});
const STATUSES = ["New", "Processing", "Shipped", "Delivered", "Cancelled"];

/* ---------------- helpers ---------------- */
const send = (res, code, body, headers = {}) => {
  const isObj = typeof body === "object" && !Buffer.isBuffer(body);
  res.writeHead(code, {
    "Content-Type": isObj ? "application/json; charset=utf-8" : "text/plain; charset=utf-8",
    "Cache-Control": "no-store",
    ...headers,
  });
  res.end(isObj ? JSON.stringify(body) : body);
};
const readBody = (req, limit = 1_000_000) =>
  new Promise((ok, no) => {
    let n = 0;
    const c = [];
    req.on("data", (d) => {
      n += d.length;
      if (n > limit) {
        no(Object.assign(new Error("Request too large."), { code: 413 }));
        req.destroy();
      } else c.push(d);
    });
    req.on("end", () => {
      try {
        ok(c.length ? JSON.parse(Buffer.concat(c).toString("utf8")) : {});
      } catch {
        no(Object.assign(new Error("Invalid JSON."), { code: 400 }));
      }
    });
    req.on("error", no);
  });
const hits = new Map();
const limited = (key, max, windowMs) => {
  const now = Date.now(),
    a = (hits.get(key) || []).filter((t) => now - t < windowMs);
  a.push(now);
  hits.set(key, a);
  return a.length > max;
};
setInterval(() => {
  const now = Date.now();
  for (const [k, a] of hits) if (!a.some((t) => now - t < 3600e3)) hits.delete(k);
}, 600e3).unref();
const ip = (req) =>
  (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || req.socket.remoteAddress;
const safeEq = (a, b) => {
  const x = crypto.createHash("sha256").update(String(a)).digest(),
    y = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
};
const normPhone = (v) => {
  let s = String(v || "").replace(/[\s\-().]/g, "");
  if (s.startsWith("+20")) s = "0" + s.slice(3);
  else if (s.startsWith("0020")) s = "0" + s.slice(4);
  else if (/^20\d{10}$/.test(s)) s = "0" + s.slice(2);
  else if (/^1[0125]\d{8}$/.test(s)) s = "0" + s;
  return s;
};
const clip = (v, n) =>
  String(v ?? "")
    .trim()
    .slice(0, n);
class HttpError extends Error {
  constructor(code, msg) {
    super(msg);
    this.code = code;
  }
}
const fail = (code, msg) => {
  throw new HttpError(code, msg);
};

/* ---------------- API ---------------- */
async function api(req, res, url) {
  await init();
  const m = req.method,
    p = url.pathname,
    S = () => kvGet("settings", {});
  if (m === "GET" && p === "/api/products")
    return send(res, 200, {
      products: (await getProducts())
        .map(withStock)
        .filter((x) => x.active !== false),
      settings: await S(),
    });
  if (m === "GET" && p === "/api/cms")
    return send(res, 200, {
      texts: await kvGet("texts", {}),
      hero: (await kvGet("hero", null)) ? "/hero.jpg?v=" + (await kvGet("heroVer", 0)) : "",
    });

  if (m === "POST" && p === "/api/orders") {
    if (limited("order:" + ip(req), 12, 3600e3))
      fail(429, "Too many orders from this connection. Please try again later.");
    const b = await readBody(req),
      c = b.customer || {},
      L = Array.isArray(b.items) ? b.items.slice(0, 50) : [];
    const name = clip(c.name, 120),
      phone = normPhone(c.phone),
      email = clip(c.email, 160),
      address = clip(c.address, 300);
    if (name.length < 2) fail(400, "Please enter your full name.");
    if (!/^01[0125]\d{8}$/.test(phone))
      fail(400, "Please enter a valid Egyptian mobile number (01X XXXX XXXX).");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
      fail(400, "Please enter a valid email address.");
    if (address.length < 8)
      fail(400, "Please enter your full delivery address: street, area and city.");
    if (!["cash", "card", "wallet", "instapay", "applepay"].includes(b.paymentMethod))
      fail(400, "Please choose how you would like to pay.");
    const o = await db.tx(async (t) => {
      let order;
      const prods = new Map(
          (await getProducts(t))
            .map(withStock)
            .map((x) => [x.id, x]),
        ),
        items = [];
      for (const l of L) {
        const pr = prods.get(l.id);
        if (pr && pr.active !== false)
          items.push({
            id: pr.id,
            name: pr.name,
            color: pr.color,
            size: String(l.size || "M"),
            quantity: Math.max(1, Math.min(20, Math.floor(+l.quantity) || 1)),
            unitPrice: +pr.price,
          });
      }
      if (!items.length) fail(400, "Your bag is empty or its items are no longer available.");
      for (const it of items) {
        const pr = prods.get(it.id),
          left = (pr.sizeStock || {})[it.size];
        if (!(left >= it.quantity))
          fail(
            409,
            left > 0
              ? `Only ${left} left of ${pr.name} in size ${it.size}.`
              : `Sorry, ${pr.name} is sold out in size ${it.size}.`,
          );
      }
      const st = await kvGet("settings", {}, t),
        sub = items.reduce((n, x) => n + x.quantity * x.unitPrice, 0),
        del = sub >= st.freeOver ? 0 : st.deliveryFee,
        tot = sub + del;
      items.forEach((it) => {
        const pr = prods.get(it.id);
        pr.sizeStock[it.size] -= it.quantity;
        pr.stock = total(pr);
      });
      for (const id of new Set(items.map((i) => i.id))) await saveProduct(prods.get(id), t);
      const id =
        "SK-" +
        new Date().toISOString().slice(2, 10).replaceAll("-", "") +
        "-" +
        crypto.randomBytes(3).toString("hex").toUpperCase();
      order = {
        id,
        created_at: new Date().toISOString(),
        status: "New",
        payment_method: b.paymentMethod,
        payment_status: b.paymentMethod === "cash" ? "Pay on delivery" : "Awaiting payment",
        name,
        phone,
        email,
        address,
        items: JSON.stringify(items),
        subtotal: sub,
        delivery: del,
        total: tot,
      };
      await t.run(
        "INSERT INTO orders (id,created_at,status,payment_method,payment_status,name,phone,email,address,items,subtotal,delivery,total) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [
          order.id,
          order.created_at,
          order.status,
          order.payment_method,
          order.payment_status,
          name,
          phone,
          email,
          address,
          order.items,
          sub,
          del,
          tot,
        ],
      );
      const o = rowToOrder(order);
      o.walletNumber = st.walletNumber;
      o.instapayHandle = st.instapayHandle || "";
      o.instapayLink = st.instapayLink || "";
      o.cardUrl = st.cardUrl;
      o.applepayUrl = st.applepayUrl || "";
      o.whatsapp = st.whatsapp || "";
      o.saved = true;
      return o;
    });
    return send(res, 201, { order: o });
  }

  if (p === "/api/admin/login" && m === "POST") {
    if (limited("login:" + ip(req), 10, 900e3))
      fail(429, "Too many attempts. Try again in 15 minutes.");
    if (!ADMIN_PASSWORD)
      fail(503, "Admin is locked: set ADMIN_PASSWORD in Vercel → Settings → Environment Variables, then redeploy.");
    const b = await readBody(req);
    if (!safeEq(b.password, ADMIN_PASSWORD)) fail(401, "Wrong password.");
    return send(res, 200, { ok: true });
  }
  if (!p.startsWith("/api/admin")) fail(404, "Not found.");
  const auth = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (limited("adm:" + ip(req), 600, 60e3)) fail(429, "Too many requests.");
  if (!ADMIN_PASSWORD) fail(503, "Admin is locked: set ADMIN_PASSWORD first.");
  if (!safeEq(auth, ADMIN_PASSWORD)) {
    limited("bad:" + ip(req), 1e9, 1);
    fail(401, "Admin access required.");
  }

  if (m === "GET" && p === "/api/admin/overview") {
    const orders = (
      await db.all("SELECT * FROM orders ORDER BY created_at DESC LIMIT 2000")
    ).map(rowToOrder);
    return send(res, 200, {
      products: (await getProducts()).map(withStock),
      orders,
      settings: await S(),
      accounts: [],
      persistent: db.persistent,
    });
  }
  let r = p.match(/^\/api\/admin\/orders\/([^/]+)$/);
  if (m === "PATCH" && r) {
    const b = await readBody(req),
      id = decodeURIComponent(r[1]),
      row = await db.get("SELECT * FROM orders WHERE id=?", [id]);
    if (!row) fail(404, "Order not found.");
    if (!STATUSES.includes(b.status)) fail(400, "Invalid order status.");
    await db.tx(async (t) => {
      if (b.status === "Cancelled" && !row.restocked) {
        const prods = new Map(
          (await getProducts(t))
            .map(withStock)
            .map((x) => [x.id, x]),
        );
        for (const i of JSON.parse(row.items)) {
          const pr = prods.get(i.id);
          if (pr) {
            pr.sizeStock[i.size] = (pr.sizeStock[i.size] || 0) + i.quantity;
            pr.stock = total(pr);
            await saveProduct(pr, t);
          }
        }
        await t.run("UPDATE orders SET restocked=1 WHERE id=?", [id]);
      }
      await t.run(
        "UPDATE orders SET status=?, payment_status=CASE WHEN ?='Paid' THEN 'Paid' ELSE payment_status END WHERE id=?",
        [b.status, b.paymentStatus || "", id],
      );
    });
    return send(res, 200, {
      order: rowToOrder(await db.get("SELECT * FROM orders WHERE id=?", [id])),
    });
  }
  if (m === "POST" && p === "/api/admin/products") {
    const b = await readBody(req);
    if (!b.name || !b.color || !(+b.price > 0))
      fail(400, "Name, colour and a valid price are required.");
    const base =
        String(b.name)
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "") || "item",
      ex = new Set((await getProducts()).map((x) => x.id)),
      id = ex.has(base) ? base + "-" + crypto.randomBytes(2).toString("hex") : base;
    const photos = fs.readdirSync(path.join(PUBLIC, "img")).filter((f) => /\.jpe?g$/.test(f));
    const pr = withStock({
      id,
      name: clip(b.name, 100),
      category: clip(b.category || "Classic fit", 40),
      color: clip(b.color, 40),
      hex: /^#[0-9a-f]{6}$/i.test(b.hex) ? b.hex : "#888888",
      photo: photos.includes(b.photo) ? b.photo : "midnight.jpeg",
      kind: "unisex",
      price: +b.price,
      sizes: ["XS", "S", "M", "L", "XL", "XXL"],
      description: "Soft, breathable fabric made for long shifts.",
      stock: Math.max(0, Math.floor(+b.stock) || 0),
      active: true,
    });
    const pos = ((await db.get("SELECT MAX(pos) AS m FROM products")).m ?? -1) + 1;
    await db.run("INSERT INTO products (id,pos,data) VALUES (?,?,?)", [
      id,
      pos,
      JSON.stringify(pr),
    ]);
    return send(res, 201, { product: pr });
  }
  r = p.match(/^\/api\/admin\/products\/([^/]+)$/);
  if (r) {
    const id = decodeURIComponent(r[1]),
      row = await db.get("SELECT data FROM products WHERE id=?", [id]);
    if (!row) fail(404, "Product not found.");
    const pr = withStock(JSON.parse(row.data));
    if (m === "DELETE") {
      await db.run("DELETE FROM products WHERE id=?", [id]);
      return send(res, 200, { ok: true });
    }
    if (m === "PATCH") {
      const b = await readBody(req);
      for (const k of ["name", "color", "category", "description", "badge"])
        if (typeof b[k] === "string") pr[k] = clip(b[k], 300);
      if (typeof b.hex === "string" && /^#[0-9a-f]{6}$/i.test(b.hex)) pr.hex = b.hex;
      if (
        typeof b.photo === "string" &&
        /^[\w.-]+\.jpe?g$/.test(b.photo) &&
        fs.existsSync(path.join(PUBLIC, "img", b.photo))
      )
        pr.photo = b.photo;
      if (b.active !== undefined) pr.active = !!b.active;
      if (b.sizeStock) {
        pr.sizes.forEach((z) => {
          pr.sizeStock[z] = Math.max(0, Math.floor(+b.sizeStock[z]) || 0);
        });
        pr.stock = total(pr);
      } else if (b.stock !== undefined) {
        const t = Math.max(0, Math.floor(+b.stock) || 0),
          n = pr.sizes.length,
          q = Math.floor(t / n);
        pr.sizes.forEach((z, k) => (pr.sizeStock[z] = q + (k < t - q * n ? 1 : 0)));
        pr.stock = t;
      }
      if (b.price !== undefined && +b.price > 0) pr.price = +b.price;
      await saveProduct(pr);
      return send(res, 200, { product: pr });
    }
  }
  if (m === "PATCH" && p === "/api/admin/settings") {
    const b = await readBody(req),
      st = await S();
    if (b.flatPrice !== undefined && +b.flatPrice > 0) {
      st.flatPrice = +b.flatPrice;
      for (const pr of await getProducts()) {
        pr.price = st.flatPrice;
        await saveProduct(pr);
      }
    }
    for (const k of ["deliveryFee", "freeOver"])
      if (b[k] !== undefined && b[k] !== "" && +b[k] >= 0) st[k] = +b[k];
    for (const k of ["walletNumber", "instapayHandle", "instapayLink", "applepayUrl", "cardUrl", "whatsapp", "contactEmail"])
      if (typeof b[k] === "string") st[k] = clip(b[k], 200);
    if (typeof b.announcement === "string") st.announcement = clip(b.announcement, 180);
    await kvSet("settings", st);
    return send(res, 200, { settings: st });
  }
  if (m === "PUT" && p === "/api/admin/texts") {
    const b = await readBody(req, 500_000);
    if (typeof b.texts !== "object" || !b.texts) fail(400, "Invalid texts.");
    await kvSet("texts", b.texts);
    return send(res, 200, { ok: true });
  }
  if (m === "PUT" && p === "/api/admin/hero") {
    const b = await readBody(req, 3_000_000);
    if (!/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(b.data || ""))
      fail(400, "Please upload a JPEG image.");
    await kvSet("hero", b.data);
    await kvSet("heroVer", Date.now());
    return send(res, 200, { hero: "/hero.jpg?v=" + (await kvGet("heroVer", 0)) });
  }
  if (m === "DELETE" && p === "/api/admin/hero") {
    await kvDel("hero");
    return send(res, 200, { hero: "" });
  }
  fail(404, "Admin endpoint not found.");
}

/* ---------------- static files ---------------- */
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".jpeg": "image/jpeg",
  ".jpg": "image/jpeg",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".webp": "image/webp",
  ".txt": "text/plain",
  ".json": "application/json",
};
async function serveStatic(req, res, url) {
  if (url.pathname === "/hero.jpg") {
    await init();
    const d = await kvGet("hero", null);
    if (!d) return send(res, 404, "No hero");
    return send(res, 200, Buffer.from(d.split(",")[1], "base64"), {
      "Content-Type": "image/jpeg",
      "Cache-Control": "public, max-age=31536000, immutable",
    });
  }
  let p = decodeURIComponent(url.pathname);
  if (p === "/") p = "/index.html";
  else if (p === "/admin" || p === "/admin/") p = "/index-owner.html";
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile())
    return send(res, 404, "Not found");
  const ext = path.extname(file),
    html = ext === ".html";
  res.writeHead(200, {
    "Content-Type": MIME[ext] || "application/octet-stream",
    "Cache-Control": html
      ? "no-cache"
      : /\/(img)\//.test(p)
        ? "public, max-age=604800"
        : "no-cache",
  });
  fs.createReadStream(file).pipe(res);
}

async function handler(req, res) {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "same-origin");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  try {
    const url = new URL(req.url, "http://x");
    if (url.pathname.startsWith("/api/")) return await api(req, res, url);
    if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Method not allowed");
    await serveStatic(req, res, url);
  } catch (e) {
    if (e instanceof HttpError || e.code === 413 || e.code === 400)
      return send(res, e.code, { error: e.message });
    console.error(e);
    send(res, 500, { error: "Something went wrong. Please try again." });
  }
}
module.exports = { handler };

/* run as a normal server (computer, Render, Docker). On Vercel, api/index.js uses `handler`. */
if (require.main === module) {
  http
    .createServer(handler)
    .listen(PORT, () =>
      console.log(`Skrps Studio running on http://localhost:${PORT}  (admin: /admin)`),
    );
  process.on("SIGTERM", () => {
    db.close();
    process.exit(0);
  });
}
