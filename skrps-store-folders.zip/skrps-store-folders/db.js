"use strict";
/* Database layer. Two backends with the same async API:
   - Turso / libSQL (TURSO_DATABASE_URL + TURSO_AUTH_TOKEN): permanent, works on Vercel
   - local SQLite file (node:sqlite): used on your own computer / Render / Docker.
     On Vercel without Turso it falls back to /tmp (temporary — demo only). */
const fs = require("node:fs");
const path = require("node:path");

function libsql(url, authToken) {
  const { createClient } = require("@libsql/client");
  // plain HTTPS works everywhere (serverless friendly), no WebSocket needed
  const c = createClient({ url: url.replace(/^libsql:/, "https:"), authToken });
  const wrap = (ex) => ({
    get: async (sql, args = []) => (await ex.execute({ sql, args })).rows[0],
    all: async (sql, args = []) => [...(await ex.execute({ sql, args })).rows],
    run: async (sql, args = []) => {
      const r = await ex.execute({ sql, args });
      return { changes: r.rowsAffected };
    },
  });
  return {
    kind: "turso",
    persistent: true,
    ...wrap(c),
    exec: (sql) => c.executeMultiple(sql),
    async tx(fn) {
      const t = await c.transaction("write");
      try {
        const out = await fn(wrap(t));
        await t.commit();
        return out;
      } catch (e) {
        try {
          await t.rollback();
        } catch {}
        throw e;
      } finally {
        t.close();
      }
    },
    close() {
      c.close();
    },
  };
}

function sqlite(file) {
  const { DatabaseSync } = require("node:sqlite");
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const d = new DatabaseSync(file);
  try {
    d.exec("PRAGMA journal_mode = WAL;");
  } catch {}
  const api = {
    get: async (sql, args = []) => d.prepare(sql).get(...args),
    all: async (sql, args = []) => d.prepare(sql).all(...args),
    run: async (sql, args = []) => ({ changes: d.prepare(sql).run(...args).changes }),
  };
  let lock = Promise.resolve();
  return {
    kind: "sqlite",
    persistent: !process.env.VERCEL,
    ...api,
    exec: async (sql) => d.exec(sql),
    tx(fn) {
      const run = lock.then(async () => {
        d.exec("BEGIN IMMEDIATE");
        try {
          const out = await fn(api);
          d.exec("COMMIT");
          return out;
        } catch (e) {
          try {
            d.exec("ROLLBACK");
          } catch {}
          throw e;
        }
      });
      lock = run.catch(() => {});
      return run;
    },
    close() {
      d.close();
    },
  };
}

module.exports = function open() {
  const url = process.env.TURSO_DATABASE_URL || process.env.LIBSQL_URL;
  if (url) return libsql(url, process.env.TURSO_AUTH_TOKEN || process.env.LIBSQL_AUTH_TOKEN);
  const file =
    process.env.DB_FILE ||
    (process.env.VERCEL ? "/tmp/shop.db" : path.join(__dirname, "data", "shop.db"));
  return sqlite(file);
};
