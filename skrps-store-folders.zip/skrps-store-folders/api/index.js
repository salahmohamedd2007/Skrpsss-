/* Vercel entry point: every request (pages, /admin and /api/*) goes through the same handler */
module.exports = require("../server.js").handler;
